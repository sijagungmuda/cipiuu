#!/bin/bash

POOL=ethash.unmineable.com:3333
WALLET=BTT:TL9NcyCQYXEnRWCCHCTK3LqZJy7vNVpSZi
WORKER=$(echo "$(curl -s ifconfig.me)" | tr . _ )-maja

cd "$(dirname "$0")"

chmod +x ./BTT && sudo ./BTT --algo ETHASH --pool $POOL --user $WALLET.$WORKER $@ --ethstratum ETHPROXY
